# ♟️ SchackDebatt MVP

En gamifierad debattplattform där åsikter är drag i ett schackparti.
