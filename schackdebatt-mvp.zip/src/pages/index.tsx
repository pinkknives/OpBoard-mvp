export default function Home() {
  return <div>Välkommen till SchackDebatt!</div>;
}