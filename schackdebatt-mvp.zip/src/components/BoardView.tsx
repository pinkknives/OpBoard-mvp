export default function BoardView() {
  return <div>Brädvy kommer här</div>;
}