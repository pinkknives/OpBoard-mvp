export default function VoteButton() {
  return <button>👍 Rösta</button>;
}