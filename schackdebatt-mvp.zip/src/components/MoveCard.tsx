export default function MoveCard({ text }: { text: string }) {
  return <div>{text}</div>;
}