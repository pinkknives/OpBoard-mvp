create table users (id uuid primary key, team text);
